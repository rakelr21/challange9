package Challange5;

public class BangunDatar {
	
	double Luas(){
		return 0;
	}
	
	double Keliling(){
		return 0;
	}
}
