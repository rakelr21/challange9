package Challange5;

public class Persegipanjang extends BangunDatar{
	private int Panjang1;
	private int Lebar;
	
	@Override
	double Luas() {
		double Luas = Panjang1 * Lebar;
		System.out.println("Luas Persegi Panjang: " + Luas);
		return super.Luas();
	}

	@Override
	double Keliling() {
		double Keliling = 2 * (Panjang1 + Lebar);
		System.out.println("Keliling Persegi Panjang: " + Keliling);
		return super.Keliling();
	}

	public int getPanjang1() {
		return Panjang1;
	}

	public void setPanjang1(int panjang1) {
		Panjang1 = panjang1;
	}

	public int getLebar() {
		return Lebar;
	}

	public void setLebar(int lebar) {
		Lebar = lebar;
	}

	public Persegipanjang(int Panjang1, int Lebar) {
		super();
		this.Panjang1 = Panjang1;
		this.Lebar = Lebar;
	}


}
