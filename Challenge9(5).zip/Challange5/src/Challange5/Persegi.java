package Challange5;

public class Persegi extends BangunDatar{
	
	private int Panjang;
	
	@Override
	double Luas() {
		double Luas = Panjang * Panjang;
		System.out.println("Luas Persegi: " + Luas);
		return super.Luas();
	}

	@Override
	double Keliling() {
		double Keliling = 4 * Panjang;
		System.out.println("Keliling Persegi: " + Keliling);
		return super.Keliling();
	}

	public int getPanjang() {
		return Panjang;
	}

	public void setPanjang(int panjang) {
		Panjang = panjang;
	}

	public Persegi(int Panjang) {
		super();
		this.Panjang = Panjang;
	}


}
