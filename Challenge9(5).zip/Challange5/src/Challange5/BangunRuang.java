package Challange5;

public class BangunRuang {

	double Luas() {
		return 0;
	}
	
	double Keliling() {
		return 0;
	}
	
	double Volume() {
		return 0;
	}
}
