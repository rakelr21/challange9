package Challange5;

public class Lingkaran extends BangunDatar{
	private int r;
	
	@Override
	double Luas() {
		double Luas = (float) (Math.PI * r * r);
        System.out.println("Luas lingkaran: " + Luas);
		return super.Luas();
	}

	@Override
	double Keliling() {
		double Keliling = (float) (2 * Math.PI * r);
        System.out.println("Keliling lingkaran: " + Keliling);
		return super.Keliling();
	}

	public int getR() {
		return r;
	}

	public void setR(int r) {
		this.r = r;
	}

	public Lingkaran(int r) {
		super();
		this.r = r;
	}


}
