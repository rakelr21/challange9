package Challange5;

public class Segitiga extends BangunDatar{
	private int Alas;
	private int Tinggi;
	private int Sisia; 
	private int Sisib;
	private int Sisic;

	@Override
	double Luas() {
		double Luas = Alas * Tinggi / 2;
        System.out.println("Luas Segitiga: " + Luas);
		return super.Luas();
	}

	@Override
	double Keliling() {
		double Keliling = Sisia + Sisib + Sisic;
		System.out.println("Keliling Segitiga: " + Keliling);
		return super.Keliling();
	}

	public int getAlas() {
		return Alas;
	}

	public void setAlas(int alas) {
		Alas = alas;
	}

	public int getTinggi() {
		return Tinggi;
	}

	public void setTinggi(int tinggi) {
		Tinggi = tinggi;
	}

	public int getSisia() {
		return Sisia;
	}

	public void setSisia(int sisia) {
		Sisia = sisia;
	}

	public int getSisib() {
		return Sisib;
	}

	public void setSisib(int sisib) {
		Sisib = sisib;
	}

	public int getSisic() {
		return Sisic;
	}

	public void setSisic(int sisic) {
		Sisic = sisic;
	}

	public Segitiga(int Alas, int Tinggi, int Sisia, int Sisib, int Sisic) {
		super();
		this.Alas = Alas;
		this.Tinggi = Tinggi;
		this.Sisia = Sisia;
		this.Sisib = Sisib;
		this.Sisic = Sisic;
	}


}
