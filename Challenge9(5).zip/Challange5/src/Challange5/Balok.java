package Challange5;

public class Balok extends BangunRuang{
	
	private int Panjang;
	private int Lebar;
	private int Tinggi;

	@Override
	double Luas() {
		double Luas = (2 * Panjang * Lebar) + (2 * Panjang * Tinggi) + (2 * Lebar * Tinggi);
		System.out.println("Luas balok: " + Luas);
		return super.Luas();
	}

	@Override
	double Keliling() {
		double Keliling = 4 * (Panjang + Lebar + Tinggi);
		System.out.println("Keliling balok: " + Keliling);
		return super.Keliling();
	}

	@Override
	double Volume() {
		double Volume = Panjang * Lebar * Tinggi;
		System.out.println("Volume balok adalah: " + Volume);
		return super.Volume();
	}

	public int getPanjang() {
		return Panjang;
	}

	public void setPanjang(int panjang) {
		Panjang = panjang;
	}

	public int getLebar() {
		return Lebar;
	}

	public void setLebar(int lebar) {
		Lebar = lebar;
	}

	public int getTinggi() {
		return Tinggi;
	}

	public void setTinggi(int tinggi) {
		Tinggi = tinggi;
	}

	public Balok(int Panjang, int Lebar, int Tinggi) {
		super();
		this.Panjang = Panjang;
		this.Lebar = Lebar;
		this.Tinggi = Tinggi;
	}

}
